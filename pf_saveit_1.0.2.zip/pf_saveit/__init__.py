# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "PF: SaveIt",
    "author" : "MaK", 
    "description" : "Save and Export FBX for PF pipeline",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 2),
    "location" : "",
    "waring" : "",
    "doc_url": "https://github.com/mkolcun/PF_SaveIt", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import os


addon_keymaps = {}
_icons = None
nodetree = {'sna_selectedobjectscoll': None, 'sna_allobjects': [], 'sna_filename': 'empty', }
class SNA_OT_Tempselectiongroups_644C7(bpy.types.Operator):
    bl_idname = "sna.tempselectiongroups_644c7"
    bl_label = "TempSelectionGroups"
    bl_description = "Creates Temp Groups of Selected Objects in Scene"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.context.scene.sna_objectsselected.clear()
        bpy.context.scene.sna_objectsposition.clear()
        bpy.context.scene.sna_objectsrotation.clear()
        bpy.context.scene.sna_objectsscale.clear()
        nodetree['sna_selectedobjectscoll'] = bpy.context.view_layer.objects.selected
        for i_46162 in range(len(nodetree['sna_selectedobjectscoll'])):
            item_E8CD6 = bpy.context.scene.sna_objectsselected.add()
            item_E8CD6.objectselected = nodetree['sna_selectedobjectscoll'][i_46162]
            item_DA379 = bpy.context.scene.sna_objectsposition.add()
            item_DA379.objectposition = getattr(nodetree['sna_selectedobjectscoll'][i_46162], 'location', None)
            item_3282C = bpy.context.scene.sna_objectsrotation.add()
            item_3282C.objectrotation = getattr(nodetree['sna_selectedobjectscoll'][i_46162], 'rotation_euler', None)
            item_248E7 = bpy.context.scene.sna_objectsscale.add()
            item_248E7.objectscale = getattr(nodetree['sna_selectedobjectscoll'][i_46162], 'scale', None)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Processingselection_C5Eb5(bpy.types.Operator):
    bl_idname = "sna.processingselection_c5eb5"
    bl_label = "ProcessingSelection"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        for i_02C95 in range(len(bpy.context.scene.sna_objectsselected.values())):
            if bpy.context.scene.sna_isbatchopt:
                bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
                bpy.context.scene.sna_objectsselected[i_02C95].objectselected.select_set(state=True, )
                bpy.ops.sna.settransforms_bf46c('INVOKE_DEFAULT', )
                bpy.ops.sna.exportfbx_batched_81d9f('INVOKE_DEFAULT', )
                setattr(bpy.context.view_layer.objects.selected[0], 'location', bpy.context.scene.sna_objectsposition[i_02C95].objectposition)
                for i_DCBE4 in range(len(bpy.context.scene.sna_objectsselected)):
                    bpy.context.scene.sna_objectsselected[i_DCBE4].objectselected.select_set(state=True, )
            else:
                bpy.ops.sna.settransforms_rotation_e31f0('INVOKE_DEFAULT', )
                bpy.ops.sna.settransforms_scale_db09c('INVOKE_DEFAULT', )
                bpy.ops.sna.exportfbx_asone_da362('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Settransforms_Location_F03C0(bpy.types.Operator):
    bl_idname = "sna.settransforms_location_f03c0"
    bl_label = "SetTransforms_Location"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.ops.view3d.snap_cursor_to_center('INVOKE_DEFAULT', )
        bpy.ops.view3d.snap_selected_to_cursor('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Settransforms_Rotation_E31F0(bpy.types.Operator):
    bl_idname = "sna.settransforms_rotation_e31f0"
    bl_label = "SetTransforms_Rotation"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.ops.object.transform_apply('INVOKE_DEFAULT', location=False, rotation=True, scale=False, properties=False)
        bpy.ops.transform.rotate(value=-1.570680022239685 * -1.0, orient_axis='X')
        bpy.ops.object.transform_apply(location=False, rotation=True, scale=False, properties=False)
        bpy.ops.transform.rotate(value=-1.570680022239685, orient_axis='X')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Settransforms_Bf46C(bpy.types.Operator):
    bl_idname = "sna.settransforms_bf46c"
    bl_label = "SetTransforms"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.ops.sna.settransforms_location_f03c0('INVOKE_DEFAULT', )
        bpy.ops.sna.settransforms_rotation_e31f0('INVOKE_DEFAULT', )
        bpy.ops.sna.settransforms_scale_db09c('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Settransforms_Scale_Db09C(bpy.types.Operator):
    bl_idname = "sna.settransforms_scale_db09c"
    bl_label = "SetTransforms_Scale"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.ops.object.transform_apply('INVOKE_DEFAULT', location=False, rotation=False, scale=True, properties=False)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Exportfbx_Batched_81D9F(bpy.types.Operator):
    bl_idname = "sna.exportfbx_batched_81d9f"
    bl_label = "ExportFBX_Batched"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.ops.export_scene.fbx(filepath=os.path.dirname(bpy.data.filepath) + '\\' + getattr(bpy.context.view_layer.objects.selected[0], 'name', None) + '.fbx', use_selection=True, apply_scale_options='FBX_SCALE_UNITS', use_space_transform=False, bake_space_transform=False, use_mesh_edges=True, use_custom_props=False, bake_anim=False, axis_forward='Y', axis_up='Z')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Batchon_10Cb4(bpy.types.Operator):
    bl_idname = "sna.batchon_10cb4"
    bl_label = "BatchOn"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.context.scene.sna_isbatchopt = True
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Batchoff_91078(bpy.types.Operator):
    bl_idname = "sna.batchoff_91078"
    bl_label = "BatchOff"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.context.scene.sna_isbatchopt = False
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_view3d_pt_tools_active_53D79(self, context):
    if not (False):
        layout = self.layout
        layout.label(text='PF: SaveIt', icon_value=0)
        box_8F3C2 = layout.box()
        box_8F3C2.alert = False
        box_8F3C2.enabled = True
        box_8F3C2.active = True
        box_8F3C2.use_property_split = False
        box_8F3C2.use_property_decorate = False
        box_8F3C2.alignment = 'Expand'.upper()
        box_8F3C2.scale_x = 1.0
        box_8F3C2.scale_y = 1.0
        op = box_8F3C2.operator('sna.save_40d02', text="Save 'n Export", icon_value=70, emboss=True, depress=False)
        row_17927 = box_8F3C2.row(heading='', align=False)
        row_17927.alert = False
        row_17927.enabled = True
        row_17927.active = True
        row_17927.use_property_split = False
        row_17927.use_property_decorate = False
        row_17927.scale_x = 1.0
        row_17927.scale_y = 1.0
        row_17927.alignment = 'Expand'.upper()
        if bpy.context.scene.sna_isbatchopt:
            op = row_17927.operator('sna.batchoff_91078', text='', icon_value=36, emboss=True, depress=True)
        else:
            op = row_17927.operator('sna.batchon_10cb4', text='', icon_value=33, emboss=True, depress=False)
        row_17927.label(text='Batch Selected Objects', icon_value=0)


class SNA_OT_Save_40D02(bpy.types.Operator):
    bl_idname = "sna.save_40d02"
    bl_label = "Save"
    bl_description = "Save it"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        if os.path.exists(bpy.data.filepath):
            bpy.ops.sna.blendname_fbb6a('INVOKE_DEFAULT', )
            self.report({'INFO'}, message='Processing . . .')
        else:
            self.report({'WARNING'}, message='Save Workfile first!')
            bpy.ops.wm.save_mainfile('INVOKE_DEFAULT', )
        if bpy.context.view_layer.objects.selected:
            bpy.ops.sna.blendname_fbb6a('INVOKE_DEFAULT', )
            bpy.ops.sna.tempselectiongroups_644c7('INVOKE_DEFAULT', )
            bpy.ops.sna.processingselection_c5eb5('INVOKE_DEFAULT', )
            self.report({'INFO'}, message='Saved!')
        else:
            self.report({'WARNING'}, message='File Saved. Nothing Exported.')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Exportfbx_Asone_Da362(bpy.types.Operator):
    bl_idname = "sna.exportfbx_asone_da362"
    bl_label = "ExportFBX_AsOne"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.ops.export_scene.fbx(filepath=os.path.dirname(bpy.data.filepath) + '\\' + nodetree['sna_filename'] + '_' + getattr(bpy.context.view_layer.objects.active, 'name', None) + '.fbx', use_selection=True, apply_scale_options='FBX_SCALE_UNITS', use_space_transform=True, bake_space_transform=True, use_mesh_edges=True, use_custom_props=True, add_leaf_bones=False, bake_anim=False, axis_forward='Y', axis_up='Z')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Blendname_Fbb6A(bpy.types.Operator):
    bl_idname = "sna.blendname_fbb6a"
    bl_label = "BlendName"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        filename = None
        import bpy
        filename = bpy.path.basename(bpy.data.filepath)
        filename = os.path.splitext(filename)[0]
        nodetree['sna_filename'] = filename
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_GROUP_sna_objects(bpy.types.PropertyGroup):
    objectselected: bpy.props.PointerProperty(name='ObjectSelected', description='', type=bpy.types.Object)
    objectposition: bpy.props.FloatVectorProperty(name='ObjectPosition', description='', size=3, default=(0.0, 0.0, 0.0), subtype='NONE', unit='NONE', step=3, precision=6)
    objectrotation: bpy.props.FloatVectorProperty(name='ObjectRotation', description='', size=3, default=(0.0, 0.0, 0.0), subtype='NONE', unit='NONE', step=3, precision=6)
    objectscale: bpy.props.FloatVectorProperty(name='ObjectScale', description='', size=3, default=(0.0, 0.0, 0.0), subtype='NONE', unit='NONE', step=3, precision=6)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_GROUP_sna_objects)
    bpy.types.Scene.sna_isbatchopt = bpy.props.BoolProperty(name='IsBatchOpt', description='', default=False)
    bpy.types.Scene.sna_objectsselected = bpy.props.CollectionProperty(name='ObjectsSelected', description='', type=SNA_GROUP_sna_objects)
    bpy.types.Scene.sna_objectsnames = bpy.props.CollectionProperty(name='ObjectsNames', description='', type=SNA_GROUP_sna_objects)
    bpy.types.Scene.sna_objectsposition = bpy.props.CollectionProperty(name='ObjectsPosition', description='', type=SNA_GROUP_sna_objects)
    bpy.types.Scene.sna_objectsrotation = bpy.props.CollectionProperty(name='ObjectsRotation', description='', type=SNA_GROUP_sna_objects)
    bpy.types.Scene.sna_objectsscale = bpy.props.CollectionProperty(name='ObjectsScale', description='', type=SNA_GROUP_sna_objects)
    bpy.utils.register_class(SNA_OT_Tempselectiongroups_644C7)
    bpy.utils.register_class(SNA_OT_Processingselection_C5Eb5)
    bpy.utils.register_class(SNA_OT_Settransforms_Location_F03C0)
    bpy.utils.register_class(SNA_OT_Settransforms_Rotation_E31F0)
    bpy.utils.register_class(SNA_OT_Settransforms_Bf46C)
    bpy.utils.register_class(SNA_OT_Settransforms_Scale_Db09C)
    bpy.utils.register_class(SNA_OT_Exportfbx_Batched_81D9F)
    bpy.utils.register_class(SNA_OT_Batchon_10Cb4)
    bpy.utils.register_class(SNA_OT_Batchoff_91078)
    bpy.types.VIEW3D_PT_tools_active.prepend(sna_add_to_view3d_pt_tools_active_53D79)
    bpy.utils.register_class(SNA_OT_Save_40D02)
    bpy.utils.register_class(SNA_OT_Exportfbx_Asone_Da362)
    bpy.utils.register_class(SNA_OT_Blendname_Fbb6A)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_objectsscale
    del bpy.types.Scene.sna_objectsrotation
    del bpy.types.Scene.sna_objectsposition
    del bpy.types.Scene.sna_objectsnames
    del bpy.types.Scene.sna_objectsselected
    del bpy.types.Scene.sna_isbatchopt
    bpy.utils.unregister_class(SNA_GROUP_sna_objects)
    bpy.utils.unregister_class(SNA_OT_Tempselectiongroups_644C7)
    bpy.utils.unregister_class(SNA_OT_Processingselection_C5Eb5)
    bpy.utils.unregister_class(SNA_OT_Settransforms_Location_F03C0)
    bpy.utils.unregister_class(SNA_OT_Settransforms_Rotation_E31F0)
    bpy.utils.unregister_class(SNA_OT_Settransforms_Bf46C)
    bpy.utils.unregister_class(SNA_OT_Settransforms_Scale_Db09C)
    bpy.utils.unregister_class(SNA_OT_Exportfbx_Batched_81D9F)
    bpy.utils.unregister_class(SNA_OT_Batchon_10Cb4)
    bpy.utils.unregister_class(SNA_OT_Batchoff_91078)
    bpy.types.VIEW3D_PT_tools_active.remove(sna_add_to_view3d_pt_tools_active_53D79)
    bpy.utils.unregister_class(SNA_OT_Save_40D02)
    bpy.utils.unregister_class(SNA_OT_Exportfbx_Asone_Da362)
    bpy.utils.unregister_class(SNA_OT_Blendname_Fbb6A)
